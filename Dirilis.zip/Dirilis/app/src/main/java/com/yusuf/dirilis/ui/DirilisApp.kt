package com.yusuf.dirilis.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.yusuf.dirilis.data.AppContainer
import com.yusuf.dirilis.ui.screens.*

sealed class Dest(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Dest("home", "Ana", Icons.Outlined.Shield)
    data object Journal : Dest("journal", "Günlük", Icons.Outlined.MenuBook)
    data object Insight : Dest("insight", "Veri", Icons.Outlined.BarChart)
    data object Settings : Dest("settings", "Ayar", Icons.Outlined.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirilisApp(container: AppContainer) {
    val nav = rememberNavController()
    val prefs by container.prefs.flow.collectAsState(initial = null)
    val current = prefs

    if (current == null) {
        Surface { /* yüklenirken boş */ }
        return
    }

    if (!current.onboarded) {
        OnboardingScreen(container) { /* tamamlandığında otomatik geçiş */ }
        return
    }

    val items = listOf(Dest.Home, Dest.Journal, Dest.Insight, Dest.Settings)

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val backStack by nav.currentBackStackEntryAsState()
                val currentRoute = backStack?.destination?.route
                items.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            nav.navigate(dest.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }
    ) { inner ->
        NavHost(
            navController = nav,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(inner)
        ) {
            composable(Dest.Home.route) { HomeScreen(container, onPanic = { nav.navigate("panic") }) }
            composable(Dest.Journal.route) { JournalScreen(container) }
            composable(Dest.Insight.route) { InsightScreen(container) }
            composable(Dest.Settings.route) { SettingsScreen(container) }
            composable("panic") { PanicScreen(container, onClose = { nav.popBackStack() }) }
        }
    }
}
