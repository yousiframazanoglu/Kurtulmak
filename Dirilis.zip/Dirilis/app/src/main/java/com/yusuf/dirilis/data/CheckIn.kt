package com.yusuf.dirilis.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "checkins")
data class CheckIn(
    @PrimaryKey val dayKey: String, // "2026-05-25" formatında
    val timestamp: Long,
    val clean: Boolean, // true = temiz gün, false = düştü
    val urgeIntensity: Int, // 0-10
    val note: String = ""
)

@Dao
interface CheckInDao {
    @Query("SELECT * FROM checkins ORDER BY dayKey DESC")
    fun getAll(): Flow<List<CheckIn>>

    @Query("SELECT * FROM checkins WHERE dayKey = :dayKey LIMIT 1")
    suspend fun getByDay(dayKey: String): CheckIn?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(checkIn: CheckIn)

    @Query("SELECT COUNT(*) FROM checkins WHERE clean = 1")
    suspend fun totalCleanDays(): Int
}
