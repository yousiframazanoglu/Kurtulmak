package com.yusuf.dirilis.util

import com.yusuf.dirilis.data.UserPrefs
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object DateUtil {

    private val dayKeyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val displayFormat = SimpleDateFormat("d MMMM yyyy", Locale("tr"))
    private val shortFormat = SimpleDateFormat("d MMM", Locale("tr"))

    fun todayKey(): String = dayKeyFormat.format(Date())

    fun dayKey(ts: Long): String = dayKeyFormat.format(Date(ts))

    fun displayDate(ts: Long): String = displayFormat.format(Date(ts))

    fun shortDate(ts: Long): String = shortFormat.format(Date(ts))

    fun daysSince(startMs: Long): Long {
        if (startMs <= 0) return 0
        val diff = System.currentTimeMillis() - startMs
        return TimeUnit.MILLISECONDS.toDays(diff).coerceAtLeast(0)
    }

    fun hoursMinutesSince(startMs: Long): Pair<Long, Long> {
        if (startMs <= 0) return 0L to 0L
        val diff = System.currentTimeMillis() - startMs
        val totalMin = TimeUnit.MILLISECONDS.toMinutes(diff)
        val days = totalMin / (60 * 24)
        val remMin = totalMin - days * 60 * 24
        val hours = remMin / 60
        val mins = remMin - hours * 60
        return hours to mins
    }

    /**
     * Bugün "izin günü" mü?
     * mode: "none" -> hiç izin yok
     * mode: "weekly" -> her hafta belirli bir gün (1=Pazar, 2=Pazartesi ... 7=Cumartesi)
     * mode: "monthly" -> her ayın belirli günü
     */
    fun isAllowedDay(prefs: UserPrefs): Boolean {
        if (prefs.allowedDayMode == "none") return false
        val cal = Calendar.getInstance()
        return when (prefs.allowedDayMode) {
            "weekly" -> cal.get(Calendar.DAY_OF_WEEK) == prefs.allowedWeekday
            "monthly" -> cal.get(Calendar.DAY_OF_MONTH) == prefs.allowedMonthday
            else -> false
        }
    }

    fun weekdayName(day: Int): String = when (day) {
        Calendar.SUNDAY -> "Pazar"
        Calendar.MONDAY -> "Pazartesi"
        Calendar.TUESDAY -> "Salı"
        Calendar.WEDNESDAY -> "Çarşamba"
        Calendar.THURSDAY -> "Perşembe"
        Calendar.FRIDAY -> "Cuma"
        Calendar.SATURDAY -> "Cumartesi"
        else -> "—"
    }
}
