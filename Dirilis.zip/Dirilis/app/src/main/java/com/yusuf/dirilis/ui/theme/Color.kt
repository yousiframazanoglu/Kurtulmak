package com.yusuf.dirilis.ui.theme

import androidx.compose.ui.graphics.Color

// Derin lacivert/gece teması — manevi, güçlü, sakin
val MidnightBase = Color(0xFF0A0E27)
val MidnightDeep = Color(0xFF050818)
val MidnightSurface = Color(0xFF131838)
val MidnightSurfaceHigh = Color(0xFF1E2547)

// Altın aksan — başarı, ışık, dönüşüm
val GoldPrimary = Color(0xFFE4B962)
val GoldSoft = Color(0xFFF4D38A)
val GoldDeep = Color(0xFFB8893A)

// Destek renkleri
val EmberRed = Color(0xFFE85A4F)      // panik butonu, uyarı
val SageGreen = Color(0xFF7FB069)     // başarı, temiz gün
val MistGray = Color(0xFFB8B9C9)      // ikincil metin
val PearlWhite = Color(0xFFF5F2E8)    // ana metin

// Açık tema (kullanılırsa)
val LightBase = Color(0xFFFAF7F0)
val LightSurface = Color(0xFFFFFFFF)
val LightInk = Color(0xFF1A1D35)
