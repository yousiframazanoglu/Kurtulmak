package com.yusuf.dirilis.work

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.yusuf.dirilis.DirilisApplication
import com.yusuf.dirilis.MainActivity
import com.yusuf.dirilis.data.Content
import com.yusuf.dirilis.data.PrefsRepository
import com.yusuf.dirilis.util.DateUtil
import kotlinx.coroutines.flow.first

class DailyReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val prefs = PrefsRepository(applicationContext).flow.first()
        val days = DateUtil.daysSince(prefs.startDate)
        val card = Content.cards.random()

        val title = if (days > 0) "$days. gün — devam et" else "Diriliş seni bekliyor"
        val text = card.body.take(120) + if (card.body.length > 120) "…" else ""

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pending = PendingIntent.getActivity(
            applicationContext, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notif = NotificationCompat.Builder(applicationContext, DirilisApplication.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        try {
            NotificationManagerCompat.from(applicationContext).notify(1001, notif)
        } catch (_: SecurityException) { /* izin yok, sessiz geç */ }
        return Result.success()
    }
}
