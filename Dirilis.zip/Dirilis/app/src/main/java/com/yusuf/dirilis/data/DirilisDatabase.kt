package com.yusuf.dirilis.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [JournalEntry::class, CheckIn::class],
    version = 1,
    exportSchema = false
)
abstract class DirilisDatabase : RoomDatabase() {
    abstract fun journalDao(): JournalDao
    abstract fun checkInDao(): CheckInDao

    companion object {
        @Volatile private var INSTANCE: DirilisDatabase? = null

        fun get(context: Context): DirilisDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DirilisDatabase::class.java,
                    "dirilis.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
