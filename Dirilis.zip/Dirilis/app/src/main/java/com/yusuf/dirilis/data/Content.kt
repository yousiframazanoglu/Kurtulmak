package com.yusuf.dirilis.data

object Content {

    // Nörobilim ve davranış bilimi temelli günlük kartlar (Türkçe + cinsiyetsiz)
    val cards: List<MotivationCard> = listOf(
        MotivationCard(
            title = "Dopamin döngüsü",
            body = "Beyin, yapay uyaranlarla aşırı dopamin salgıladığında doğal ödüllere duyarsızlaşır. " +
                    "Birkaç hafta uzak kalmak reseptörlerin yeniden hassaslaşmasını sağlar. " +
                    "Bugünkü tek görevin: tetiklendiğinde 10 dakika beklemek.",
            tag = "Nörobilim"
        ),
        MotivationCard(
            title = "Tetikleyicini tanı",
            body = "Pornoya yönelten şey çoğunlukla yalnızlık, can sıkıntısı, stres veya uykusuzluktur. " +
                    "Bunlardan biri olduğunda asıl ihtiyacı karşıla: bir arkadaşı ara, dışarı çık, su iç.",
            tag = "Davranış"
        ),
        MotivationCard(
            title = "İrade kası",
            body = "İrade sınırlı bir kaynaktır. Bu yüzden 'direnmeye' güvenme — ortamı değiştir. " +
                    "Telefonu odadan çıkar, tarayıcıya filtre kur, sıkıldığında ne yapacağını önceden planla.",
            tag = "Strateji"
        ),
        MotivationCard(
            title = "Uyku ve geri çekilme",
            body = "İlk 7-14 gün uyku bozuklukları, sinirlilik, beyin sisi olabilir. Bu geçicidir. " +
                    "Ağır egzersiz ve erken yatış bu dönemi belirgin şekilde kısaltır.",
            tag = "Beden"
        ),
        MotivationCard(
            title = "Tek bir an, tüm yolu belirlemez",
            body = "Düştüysen başa dönmedin. 30 günlük temizlik + 1 düşüş, sıfırdan başlayan birinin " +
                    "30 gün ilerisindesin demektir. Suçluluk değil, analiz: hangi tetikleyici?",
            tag = "Zihin"
        ),
        MotivationCard(
            title = "10 dakika kuralı",
            body = "Dürtü bir dalga gibidir; tepe noktası 10-20 dakikadır, sonra söner. " +
                    "Bu süreyi geçirmek için fiziksel bir şey yap: yürüyüş, soğuk su, 20 şınav.",
            tag = "Teknik"
        ),
        MotivationCard(
            title = "Beden imajı ve karşılaştırma",
            body = "Pornografi, gerçek insan ilişkilerini ve bedenleri çarpıtarak algılar. " +
                    "Bırakmanın bir hediyesi: gerçek hayatta gerçek insanları yeniden çekici bulabilmek.",
            tag = "İlişki"
        ),
        MotivationCard(
            title = "Cinsel sağlık",
            body = "Aşırı tüketim hem erkeklerde hem kadınlarda cinsel işlev bozukluğu, " +
                    "duyarlılık kaybı ve gerçek partnerden uzaklaşma ile ilişkilendirilmiştir. " +
                    "Mola, beden için bir onarım dönemidir.",
            tag = "Sağlık"
        ),
        MotivationCard(
            title = "Kimlik değişimi",
            body = "'Bırakmaya çalışıyorum' yerine 'ben bunu yapan biri değilim' de. " +
                    "Davranış değil, kimlik değişimi kalıcı sonuç verir (James Clear).",
            tag = "Zihin"
        ),
        MotivationCard(
            title = "Yedek plan",
            body = "Tetiklendiğinde ne yapacağını ŞİMDİ yaz. Üç adım belirle: " +
                    "1) yer değiştir, 2) bir kişiye mesaj at, 3) 20 dk fiziksel aktivite.",
            tag = "Strateji"
        ),
        MotivationCard(
            title = "Yalnız değilsin",
            body = "Dünya genelinde milyonlarca insan bu döngüden çıktı. " +
                    "Üniversite öğrencilerinin yarısından fazlası bir noktada bu sorunu yaşadığını söylüyor. " +
                    "Utanç döngüyü besler; konuşmak kırar.",
            tag = "Topluluk"
        ),
        MotivationCard(
            title = "Niye?",
            body = "Bırakma sebebini bir cümlede yaz ve telefonunda görünür bir yere koy. " +
                    "Sebebin yeterince büyükse 'nasıl' kendiliğinden gelir.",
            tag = "Amaç"
        )
    )

    val triggers = listOf(
        "Yalnızlık", "Can sıkıntısı", "Stres", "Uykusuzluk", "Telefonda gezinme",
        "Sosyal medya", "Reklam/içerik", "Üzüntü", "Öfke", "Cinsel açlık",
        "Alkol/sigara", "Geç saat", "Yatakta telefon", "Tatil/boş gün"
    )

    val panicActivities = listOf(
        PanicActivity("4-7-8 Nefes", "4 saniye burundan al, 7 saniye tut, 8 saniye ağızdan ver. 4 tekrar.", 60),
        PanicActivity("Soğuk su", "Yüzünü 30 saniye soğuk suya tut. Vagus siniri sıfırlanır.", 30),
        PanicActivity("20 şınav", "Kalkıp 20 şınav çek. Tetiği fiziksel yorgunluk söndürür.", 90),
        PanicActivity("Dışarı çık", "Şu an evden çık, 10 dakika yürü. Ortam değişimi en güçlüsüdür.", 600),
        PanicActivity("Birine yaz", "Güvendiğin birine 'şu an zor an' yaz. Tek cümle yeter.", 30),
        PanicActivity("5-4-3-2-1", "5 gördüğün, 4 dokunduğun, 3 duyduğun, 2 kokladığın, 1 tattığın şey say.", 120)
    )

    val badges = listOf(
        Badge("first_day", "İlk Gün", "Bir gün temiz", 1),
        Badge("three_days", "Üç Gün", "Beyin uyum sağlamaya başlıyor", 3),
        Badge("week", "Bir Hafta", "Geri çekilmenin en zor kısmı geride", 7),
        Badge("two_weeks", "İki Hafta", "Yeni alışkanlık şekilleniyor", 14),
        Badge("month", "Bir Ay", "Reseptörler yeniden duyarlı", 30),
        Badge("60_days", "60 Gün", "Yeni sen", 60),
        Badge("90_days", "90 Gün", "Tam dönüşüm — bilimsel eşik", 90),
        Badge("half_year", "180 Gün", "Yarım yıl. Sen artık başka birisin.", 180),
        Badge("year", "Bir Yıl", "Bu artık kim olduğun.", 365)
    )
}

data class MotivationCard(val title: String, val body: String, val tag: String)
data class PanicActivity(val name: String, val description: String, val durationSec: Int)
data class Badge(val id: String, val name: String, val description: String, val requiredDays: Int)
