package com.yusuf.dirilis.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import android.app.Activity

private val DarkScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = MidnightDeep,
    primaryContainer = GoldDeep,
    onPrimaryContainer = PearlWhite,
    secondary = GoldSoft,
    onSecondary = MidnightDeep,
    tertiary = SageGreen,
    background = MidnightBase,
    onBackground = PearlWhite,
    surface = MidnightSurface,
    onSurface = PearlWhite,
    surfaceVariant = MidnightSurfaceHigh,
    onSurfaceVariant = MistGray,
    error = EmberRed,
    onError = PearlWhite,
    outline = MistGray,
    outlineVariant = MidnightSurfaceHigh
)

private val LightScheme = lightColorScheme(
    primary = GoldDeep,
    onPrimary = PearlWhite,
    secondary = MidnightBase,
    background = LightBase,
    onBackground = LightInk,
    surface = LightSurface,
    onSurface = LightInk,
    error = EmberRed
)

@Composable
fun DirilisTheme(
    darkTheme: Boolean = true, // varsayılan: karanlık (manevi/odaklanma havası)
    content: @Composable () -> Unit
) {
    val scheme = if (darkTheme) DarkScheme else LightScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = scheme.background.toArgb()
            window.navigationBarColor = scheme.background.toArgb()
            WindowCompat.getInsetsController(window, view)
                .isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = DirilisTypography,
        content = content
    )
}
