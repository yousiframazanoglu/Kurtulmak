package com.yusuf.dirilis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.yusuf.dirilis.data.AppContainer
import com.yusuf.dirilis.data.Content
import com.yusuf.dirilis.data.JournalEntry
import com.yusuf.dirilis.util.DateUtil
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JournalScreen(container: AppContainer) {
    val entries by container.journalDao.getAll().collectAsState(initial = emptyList())
    var showSheet by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showSheet = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Yeni kayıt")
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text(
                    "Günlük",
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Light
                )
                Text(
                    "Tetikleyicini gör, döngüyü kır.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (entries.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Outlined.MenuBook,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Henüz kayıt yok.\nDuygunu veya tetikleyicini yazarak başla.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(entries) { entry ->
                        JournalCard(entry)
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }

    if (showSheet) {
        JournalSheet(
            onDismiss = { showSheet = false },
            container = container
        )
    }
}

@Composable
private fun JournalCard(entry: JournalEntry) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    DateUtil.displayDate(entry.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.weight(1f))
                if (entry.relapsed) {
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            "düşüş",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Ruh hali: " + "★".repeat(entry.mood) + "☆".repeat(5 - entry.mood),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary)
            if (entry.triggerTags.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("Tetikleyici: " + entry.triggerTags,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (entry.note.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(entry.note, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun JournalSheet(
    onDismiss: () -> Unit,
    container: AppContainer
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    var mood by remember { mutableStateOf(3) }
    var note by remember { mutableStateOf("") }
    var relapsed by remember { mutableStateOf(false) }
    val selectedTags = remember { mutableStateListOf<String>() }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Yeni kayıt", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)

            Text("Şu an ruh halin?", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..5).forEach { i ->
                    FilterChip(
                        selected = mood == i,
                        onClick = { mood = i },
                        label = { Text("★".repeat(i)) }
                    )
                }
            }

            Text("Tetikleyiciler", style = MaterialTheme.typography.titleMedium)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Content.triggers.forEach { t ->
                    val on = selectedTags.contains(t)
                    FilterChip(
                        selected = on,
                        onClick = { if (on) selectedTags.remove(t) else selectedTags.add(t) },
                        label = { Text(t) }
                    )
                }
            }

            Text("Not", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                placeholder = { Text("Ne hissettin? Bugün ne öğrendin?") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                maxLines = 6
            )

            Surface(
                onClick = { relapsed = !relapsed },
                color = if (relapsed) MaterialTheme.colorScheme.error.copy(alpha = 0.18f)
                        else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = relapsed, onCheckedChange = { relapsed = it })
                    Column {
                        Text("Bugün düştüm", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Sayaç sıfırlanacak ama analiz için kaydet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    scope.launch {
                        container.journalDao.insert(
                            JournalEntry(
                                timestamp = System.currentTimeMillis(),
                                mood = mood,
                                triggerTags = selectedTags.joinToString(", "),
                                note = note,
                                relapsed = relapsed
                            )
                        )
                        if (relapsed) container.prefs.resetStreak()
                        onDismiss()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Kaydet")
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
