package com.yusuf.dirilis.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "dirilis_prefs")

class PrefsRepository(private val context: Context) {

    companion object {
        val START_DATE = longPreferencesKey("start_date")
        val USER_NAME = stringPreferencesKey("user_name")
        val GENDER = stringPreferencesKey("gender") // "male" | "female" | "other"
        val GOAL_DAYS = intPreferencesKey("goal_days")
        val DAILY_TIME_MIN = intPreferencesKey("daily_time_min") // izlemeye harcanan ort dakika
        val DAILY_MONEY = intPreferencesKey("daily_money") // TL/gün
        val ALLOWED_DAY_MODE = stringPreferencesKey("allowed_day_mode") // "none" | "weekly" | "monthly"
        val ALLOWED_DAY_WEEKDAY = intPreferencesKey("allowed_weekday") // 1-7
        val ALLOWED_DAY_MONTHDAY = intPreferencesKey("allowed_monthday") // 1-31
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val NOTIF_HOUR = intPreferencesKey("notif_hour")
        val NOTIF_MIN = intPreferencesKey("notif_min")
        val UNLOCKED_BADGES = stringPreferencesKey("badges") // virgüllü liste
    }

    val flow: Flow<UserPrefs> = context.dataStore.data.map { p ->
        UserPrefs(
            startDate = p[START_DATE] ?: 0L,
            userName = p[USER_NAME] ?: "",
            gender = p[GENDER] ?: "other",
            goalDays = p[GOAL_DAYS] ?: 90,
            dailyTimeMin = p[DAILY_TIME_MIN] ?: 30,
            dailyMoney = p[DAILY_MONEY] ?: 0,
            allowedDayMode = p[ALLOWED_DAY_MODE] ?: "none",
            allowedWeekday = p[ALLOWED_DAY_WEEKDAY] ?: 0,
            allowedMonthday = p[ALLOWED_DAY_MONTHDAY] ?: 0,
            onboarded = p[ONBOARDED] ?: false,
            notifHour = p[NOTIF_HOUR] ?: 9,
            notifMin = p[NOTIF_MIN] ?: 0,
            badges = (p[UNLOCKED_BADGES] ?: "").split(",").filter { it.isNotBlank() }
        )
    }

    suspend fun update(block: suspend (MutablePreferences) -> Unit) {
        context.dataStore.edit { block(it) }
    }

    suspend fun resetStreak() {
        context.dataStore.edit { it[START_DATE] = System.currentTimeMillis() }
    }

    suspend fun addBadge(badge: String) {
        context.dataStore.edit { p ->
            val current = (p[UNLOCKED_BADGES] ?: "").split(",").filter { it.isNotBlank() }.toMutableSet()
            current.add(badge)
            p[UNLOCKED_BADGES] = current.joinToString(",")
        }
    }
}

data class UserPrefs(
    val startDate: Long,
    val userName: String,
    val gender: String,
    val goalDays: Int,
    val dailyTimeMin: Int,
    val dailyMoney: Int,
    val allowedDayMode: String,
    val allowedWeekday: Int,
    val allowedMonthday: Int,
    val onboarded: Boolean,
    val notifHour: Int,
    val notifMin: Int,
    val badges: List<String>
)
