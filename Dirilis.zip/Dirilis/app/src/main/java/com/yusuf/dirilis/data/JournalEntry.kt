package com.yusuf.dirilis.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "journal_entries")
data class JournalEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val mood: Int, // 1-5
    val triggerTags: String, // virgülle ayrılmış
    val note: String,
    val relapsed: Boolean
)

@Dao
interface JournalDao {
    @Query("SELECT * FROM journal_entries ORDER BY timestamp DESC")
    fun getAll(): Flow<List<JournalEntry>>

    @Query("SELECT * FROM journal_entries WHERE timestamp >= :since ORDER BY timestamp DESC")
    fun getSince(since: Long): Flow<List<JournalEntry>>

    @Insert
    suspend fun insert(entry: JournalEntry): Long

    @Delete
    suspend fun delete(entry: JournalEntry)

    @Query("SELECT COUNT(*) FROM journal_entries WHERE relapsed = 1 AND timestamp >= :since")
    suspend fun countRelapsesSince(since: Long): Int

    @Query("SELECT timestamp FROM journal_entries WHERE relapsed = 1 ORDER BY timestamp DESC LIMIT 1")
    suspend fun lastRelapseTime(): Long?
}
