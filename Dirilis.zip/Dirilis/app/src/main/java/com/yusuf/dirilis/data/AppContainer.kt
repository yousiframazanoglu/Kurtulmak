package com.yusuf.dirilis.data

import android.content.Context

class AppContainer(context: Context) {
    private val db = DirilisDatabase.get(context)
    val journalDao = db.journalDao()
    val checkInDao = db.checkInDao()
    val prefs = PrefsRepository(context)
}
