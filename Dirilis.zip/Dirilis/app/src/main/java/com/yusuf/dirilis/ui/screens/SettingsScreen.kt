package com.yusuf.dirilis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yusuf.dirilis.data.AppContainer
import com.yusuf.dirilis.data.PrefsRepository
import com.yusuf.dirilis.util.DateUtil
import com.yusuf.dirilis.work.NotificationScheduler
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(container: AppContainer) {
    val prefs by container.prefs.flow.collectAsState(initial = null)
    val p = prefs ?: return
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current

    var showResetDialog by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("Ayarlar", style = MaterialTheme.typography.displaySmall,
            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Light)

        Spacer(Modifier.height(24.dp))

        Group("HESAP") {
            InfoRow("İsim", p.userName.ifBlank { "—" })
            InfoRow("Cinsiyet", when (p.gender) { "male" -> "Erkek"; "female" -> "Kadın"; else -> "Belirtilmemiş" })
            InfoRow("Başlangıç", if (p.startDate > 0) DateUtil.displayDate(p.startDate) else "—")
            InfoRow("Hedef", "${p.goalDays} gün")
        }

        Spacer(Modifier.height(16.dp))

        Group("İZİN GÜNÜ") {
            val mode = when (p.allowedDayMode) {
                "weekly" -> "Haftada bir — ${DateUtil.weekdayName(p.allowedWeekday)}"
                "monthly" -> "Ayda bir — her ayın ${p.allowedMonthday}. günü"
                else -> "Yok (tam mola)"
            }
            InfoRow("Mod", mode)
        }

        Spacer(Modifier.height(16.dp))

        Group("BİLDİRİM") {
            InfoRow("Günlük bildirim saati", "${"%02d".format(p.notifHour)}:${"%02d".format(p.notifMin)}")
            TextButton(
                onClick = {
                    NotificationScheduler.scheduleDaily(ctx, p.notifHour, p.notifMin)
                }
            ) { Text("Bildirimi yeniden planla") }
        }

        Spacer(Modifier.height(16.dp))

        Group("VERİ") {
            TextButton(onClick = { showResetDialog = true }) {
                Text("Streak'i sıfırla", color = MaterialTheme.colorScheme.error)
            }
        }

        Spacer(Modifier.height(24.dp))

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("DİRİLİŞ v1.0", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(4.dp))
                Text("Bu uygulama tıbbi tavsiye yerine geçmez. Eğer bağımlılık seni ciddi şekilde " +
                        "etkiliyorsa bir ruh sağlığı uzmanına danışmanı öneririz.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(Modifier.height(40.dp))
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Streak sıfırlansın mı?") },
            text = { Text("Mevcut gün sayın silinecek. Bu işlem geri alınamaz.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        container.prefs.resetStreak()
                        showResetDialog = false
                    }
                }) { Text("Sıfırla", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Vazgeç") }
            }
        )
    }
}

@Composable
private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(8.dp), content = content)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
