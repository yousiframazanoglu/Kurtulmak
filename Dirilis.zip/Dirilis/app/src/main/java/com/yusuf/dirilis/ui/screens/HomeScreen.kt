package com.yusuf.dirilis.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yusuf.dirilis.data.AppContainer
import com.yusuf.dirilis.data.Badge
import com.yusuf.dirilis.data.CheckIn
import com.yusuf.dirilis.data.Content
import com.yusuf.dirilis.data.PrefsRepository
import com.yusuf.dirilis.util.DateUtil
import kotlinx.coroutines.launch
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(container: AppContainer, onPanic: () -> Unit) {
    val prefs by container.prefs.flow.collectAsState(initial = null)
    val p = prefs ?: return
    val scope = rememberCoroutineScope()

    val days = DateUtil.daysSince(p.startDate)
    val hm = DateUtil.hoursMinutesSince(p.startDate)
    val isAllowedDay = DateUtil.isAllowedDay(p)

    // Tasarruf hesabı
    val savedMinutes = days * p.dailyTimeMin
    val savedMoney = days * p.dailyMoney

    // Bugünün kartı - tarih bazlı deterministik
    val todayCard = remember(DateUtil.todayKey()) {
        Content.cards[(DateUtil.todayKey().hashCode().let { if (it < 0) -it else it }) % Content.cards.size]
    }

    // Rozet kontrolü
    LaunchedEffect(days) {
        Content.badges.forEach { b ->
            if (days >= b.requiredDays && !p.badges.contains(b.id)) {
                container.prefs.addBadge(b.id)
            }
        }
    }

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(24.dp))

        // Selamlama
        Text(
            if (p.userName.isNotBlank()) "Merhaba, ${p.userName}" else "Merhaba",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "Diriliş",
            style = MaterialTheme.typography.displaySmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Light
        )

        Spacer(Modifier.height(24.dp))

        // Ana streak kartı
        StreakCard(days = days, hours = hm.first, minutes = hm.second, goal = p.goalDays, isAllowedDay = isAllowedDay)

        Spacer(Modifier.height(16.dp))

        // Panik butonu
        Surface(
            onClick = onPanic,
            color = MaterialTheme.colorScheme.error,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                Modifier.padding(vertical = 18.dp, horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Filled.Bolt, contentDescription = null, tint = Color.White)
                Column(Modifier.weight(1f)) {
                    Text("PANİK", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Dürtü geldi — hemen yardım", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                }
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Color.White)
            }
        }

        Spacer(Modifier.height(24.dp))

        // Bugünün kartı
        SectionLabel("BUGÜN")
        Spacer(Modifier.height(8.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp)) {
                Text(
                    todayCard.tag.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(6.dp))
                Text(todayCard.title, style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(12.dp))
                Text(
                    todayCard.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        // Check-in
        SectionLabel("BUGÜN NASIL GEÇTI?")
        Spacer(Modifier.height(8.dp))
        CheckInRow(container)

        Spacer(Modifier.height(24.dp))

        // Tasarruf
        SectionLabel("KAZANCIN")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                modifier = Modifier.weight(1f),
                value = formatTime(savedMinutes),
                label = "geri kazanılan zaman",
                icon = Icons.Outlined.Schedule
            )
            StatCard(
                modifier = Modifier.weight(1f),
                value = "${savedMoney} TL",
                label = "tasarruf",
                icon = Icons.Outlined.Savings
            )
        }

        Spacer(Modifier.height(24.dp))

        // Rozetler
        SectionLabel("ROZETLER")
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(Content.badges) { badge ->
                BadgeChip(badge, unlocked = p.badges.contains(badge.id), days = days)
            }
        }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun StreakCard(days: Long, hours: Long, minutes: Long, goal: Int, isAllowedDay: Boolean) {
    val progress = (days.toFloat() / goal).coerceIn(0f, 1f)
    val infiniteTransition = rememberInfiniteTransition(label = "ring")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            Modifier.background(
                Brush.radialGradient(
                    listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                        Color.Transparent
                    ),
                    radius = 800f
                )
            ).padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (isAllowedDay) "BUGÜN İZİN GÜNÜ" else "TEMİZ KALDIN",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isAllowedDay) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(12.dp))
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.size((180 * pulse).dp),
                        strokeWidth = 6.dp,
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "$days",
                            fontSize = 64.sp,
                            fontWeight = FontWeight.Light,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text("gün", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "${hours}sa ${minutes}dk",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    "Hedef: $goal gün — %${(progress * 100).toInt()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun CheckInRow(container: AppContainer) {
    val scope = rememberCoroutineScope()
    var todayState by remember { mutableStateOf<CheckIn?>(null) }
    val todayKey = DateUtil.todayKey()

    LaunchedEffect(todayKey) {
        todayState = container.checkInDao.getByDay(todayKey)
    }

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CheckInOption(
            modifier = Modifier.weight(1f),
            selected = todayState?.clean == true,
            label = "Temiz",
            icon = Icons.Filled.Check,
            color = MaterialTheme.colorScheme.tertiary
        ) {
            scope.launch {
                val ci = CheckIn(todayKey, System.currentTimeMillis(), clean = true, urgeIntensity = 0)
                container.checkInDao.upsert(ci)
                todayState = ci
            }
        }
        CheckInOption(
            modifier = Modifier.weight(1f),
            selected = todayState?.clean == false,
            label = "Düştüm",
            icon = Icons.Filled.Refresh,
            color = MaterialTheme.colorScheme.error
        ) {
            scope.launch {
                val ci = CheckIn(todayKey, System.currentTimeMillis(), clean = false, urgeIntensity = 8)
                container.checkInDao.upsert(ci)
                container.prefs.resetStreak()
                todayState = ci
            }
        }
    }
}

@Composable
private fun CheckInOption(
    modifier: Modifier = Modifier,
    selected: Boolean,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (selected) color.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
        border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, color) else null,
        modifier = modifier
    ) {
        Row(
            Modifier.padding(vertical = 16.dp, horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, tint = color)
            Text(label, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun StatCard(modifier: Modifier = Modifier, value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun BadgeChip(badge: Badge, unlocked: Boolean, days: Long) {
    val color = if (unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (unlocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        modifier = Modifier.width(140.dp)
    ) {
        Column(
            Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                if (unlocked) Icons.Filled.WorkspacePremium else Icons.Outlined.Lock,
                contentDescription = null,
                tint = color
            )
            Spacer(Modifier.height(8.dp))
            Text(badge.name, style = MaterialTheme.typography.titleMedium, color = color, textAlign = TextAlign.Center)
            Text(
                "${badge.requiredDays} gün",
                style = MaterialTheme.typography.labelSmall,
                color = color.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary
    )
}

private fun formatTime(totalMin: Long): String {
    val h = totalMin / 60
    val days = h / 24
    return when {
        days >= 1 -> "${days} gün"
        h >= 1 -> "${h} saat"
        else -> "${totalMin} dk"
    }
}
