package com.yusuf.dirilis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yusuf.dirilis.data.AppContainer
import com.yusuf.dirilis.util.DateUtil

@Composable
fun InsightScreen(container: AppContainer) {
    val prefs by container.prefs.flow.collectAsState(initial = null)
    val p = prefs ?: return
    val journal by container.journalDao.getAll().collectAsState(initial = emptyList())
    val checkIns by container.checkInDao.getAll().collectAsState(initial = emptyList())

    val days = DateUtil.daysSince(p.startDate)
    val cleanCount = checkIns.count { it.clean }
    val relapseCount = journal.count { it.relapsed }
    val totalEntries = journal.size

    // Tetikleyici frekansı
    val triggerFreq = journal
        .flatMap { it.triggerTags.split(",").map { t -> t.trim() }.filter { t -> t.isNotBlank() } }
        .groupingBy { it }
        .eachCount()
        .toList()
        .sortedByDescending { it.second }
        .take(5)

    val savedMinutes = days * p.dailyTimeMin
    val savedHours = savedMinutes / 60
    val savedDays = savedHours / 24
    val savedMoney = days * p.dailyMoney

    Column(
        Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            "Veri",
            style = MaterialTheme.typography.displaySmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Light
        )
        Text(
            "Yolculuğunu rakamlarla gör.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(24.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BigStat(Modifier.weight(1f), "$days", "Mevcut streak (gün)")
            BigStat(Modifier.weight(1f), "$cleanCount", "Toplam temiz gün")
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BigStat(Modifier.weight(1f), "$relapseCount", "Düşüş")
            BigStat(Modifier.weight(1f), "$totalEntries", "Günlük kaydı")
        }

        Spacer(Modifier.height(24.dp))

        Text("KAZANÇ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                KazançRow(Icons.Outlined.Schedule, "Geri kazanılan zaman", buildString {
                    when {
                        savedDays >= 1 -> append("$savedDays gün ${savedHours - savedDays * 24} sa")
                        savedHours >= 1 -> append("$savedHours sa ${savedMinutes - savedHours * 60} dk")
                        else -> append("$savedMinutes dk")
                    }
                })
                KazançRow(Icons.Outlined.Savings, "Tasarruf", "$savedMoney TL")
                KazançRow(Icons.Outlined.MenuBook, "Bu sürede okuyabileceğin kitap", "${savedMinutes / 300}")
            }
        }

        Spacer(Modifier.height(24.dp))

        if (triggerFreq.isNotEmpty()) {
            Text("EN SIK TETİKLEYİCİLER", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    val max = triggerFreq.first().second.toFloat()
                    triggerFreq.forEach { (tag, count) ->
                        Column(Modifier.padding(vertical = 6.dp)) {
                            Row {
                                Text(tag, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                Text("$count", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { count / max },
                                modifier = Modifier.fillMaxWidth().height(6.dp),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Bu tetikleyiciler senin örüntün. Önümüzdeki hafta hangisini hedefleyeceksin?",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun BigStat(modifier: Modifier, value: String, label: String) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(20.dp)) {
            Text(value, style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Light)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun KazançRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    }
}
