package com.yusuf.dirilis.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yusuf.dirilis.data.AppContainer
import com.yusuf.dirilis.data.PrefsRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(container: AppContainer, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var step by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("other") }
    var goalDays by remember { mutableStateOf(90) }
    var dailyTime by remember { mutableStateOf(30) }
    var dailyMoney by remember { mutableStateOf(0) }
    var allowedMode by remember { mutableStateOf("none") }
    var allowedWeekday by remember { mutableStateOf(1) }
    var allowedMonthday by remember { mutableStateOf(1) }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surface)
            )
        )
    ) {
        Column(
            Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(32.dp))

            Text(
                "DİRİLİŞ",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Light
            )
            Text(
                "Bir karar. Bir yol. Yeniden sen.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))

            when (step) {
                0 -> {
                    SectionTitle("Adın")
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        placeholder = { Text("Sana nasıl hitap edelim?") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    SectionTitle("Cinsiyet")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = gender == "male", onClick = { gender = "male" }, label = { Text("Erkek") })
                        FilterChip(selected = gender == "female", onClick = { gender = "female" }, label = { Text("Kadın") })
                        FilterChip(selected = gender == "other", onClick = { gender = "other" }, label = { Text("Belirtmek istemiyorum") })
                    }
                }
                1 -> {
                    SectionTitle("Hedef gün sayısı")
                    Text(
                        "$goalDays gün",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Slider(
                        value = goalDays.toFloat(),
                        onValueChange = { goalDays = it.toInt() },
                        valueRange = 7f..365f,
                        steps = 0
                    )
                    Text(
                        "Bilimsel araştırmalar 90 günü beyin için anlamlı bir eşik olarak gösteriyor.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                2 -> {
                    SectionTitle("Tasarruf hesabı")
                    Text(
                        "Önceden ortalama günde kaç dakika harcıyordun?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = dailyTime.toString(),
                        onValueChange = { dailyTime = it.toIntOrNull() ?: 0 },
                        suffix = { Text("dakika") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "İlgili harcamalar (premium, VPN vb.) — günde tahmini",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = dailyMoney.toString(),
                        onValueChange = { dailyMoney = it.toIntOrNull() ?: 0 },
                        suffix = { Text("TL") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                3 -> {
                    SectionTitle("İzin günü")
                    Text(
                        "Tamamen bırakmak en etkilisidir ama planlı bir 'izin günü' belirleyebilirsin. " +
                                "Bilinçli bir karar, kontrolsüz düşüşten her zaman iyidir.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ModeRow("none", allowedMode, "İzin günü yok — tam mola") { allowedMode = it }
                        ModeRow("weekly", allowedMode, "Haftada bir gün") { allowedMode = it }
                        ModeRow("monthly", allowedMode, "Ayda bir gün") { allowedMode = it }
                    }

                    AnimatedVisibility(allowedMode == "weekly", enter = fadeIn(), exit = fadeOut()) {
                        Column {
                            Spacer(Modifier.height(12.dp))
                            Text("Hangi gün?", style = MaterialTheme.typography.titleMedium)
                            val days = listOf("Pzr","Pzt","Sal","Çar","Per","Cum","Cmt")
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                days.forEachIndexed { i, d ->
                                    FilterChip(
                                        selected = allowedWeekday == i + 1,
                                        onClick = { allowedWeekday = i + 1 },
                                        label = { Text(d) }
                                    )
                                }
                            }
                        }
                    }
                    AnimatedVisibility(allowedMode == "monthly", enter = fadeIn(), exit = fadeOut()) {
                        Column {
                            Spacer(Modifier.height(12.dp))
                            Text("Ayın hangi günü? ($allowedMonthday)", style = MaterialTheme.typography.titleMedium)
                            Slider(
                                value = allowedMonthday.toFloat(),
                                onValueChange = { allowedMonthday = it.toInt() },
                                valueRange = 1f..28f
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(32.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                if (step > 0) {
                    OutlinedButton(onClick = { step-- }, modifier = Modifier.weight(1f)) {
                        Text("Geri")
                    }
                }
                Button(
                    onClick = {
                        if (step < 3) step++
                        else {
                            scope.launch {
                                container.prefs.update { p ->
                                    p[PrefsRepository.START_DATE] = System.currentTimeMillis()
                                    p[PrefsRepository.USER_NAME] = name
                                    p[PrefsRepository.GENDER] = gender
                                    p[PrefsRepository.GOAL_DAYS] = goalDays
                                    p[PrefsRepository.DAILY_TIME_MIN] = dailyTime
                                    p[PrefsRepository.DAILY_MONEY] = dailyMoney
                                    p[PrefsRepository.ALLOWED_DAY_MODE] = allowedMode
                                    p[PrefsRepository.ALLOWED_DAY_WEEKDAY] = allowedWeekday
                                    p[PrefsRepository.ALLOWED_DAY_MONTHDAY] = allowedMonthday
                                    p[PrefsRepository.ONBOARDED] = true
                                }
                                onDone()
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (step < 3) "Devam" else "Başla")
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun ModeRow(value: String, current: String, label: String, onSelect: (String) -> Unit) {
    Surface(
        onClick = { onSelect(value) },
        color = if (current == value) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = current == value, onClick = { onSelect(value) })
            Spacer(Modifier.width(8.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
